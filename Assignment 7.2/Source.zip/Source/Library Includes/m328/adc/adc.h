/*
 * adc.h
 *
 * Created: 10/15/2018 3:57:41 PM
 *  Author: Brandon Michelsen
 */ 


#ifndef ADC_H_
#define ADC_H_

// Function prototypes
int adc_read_10(int channel);
int adc_read_8(int channel);

#endif /* ADC_H_ */