// Function definitions for ADC_H_
//
// Author: Brandon Michelsen
// Date: 10/10/2018

#include "adc.h"
#include <avr/io.h>

